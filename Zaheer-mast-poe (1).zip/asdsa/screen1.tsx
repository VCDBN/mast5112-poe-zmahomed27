import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';

const HomeScreen = () => {
  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerText}>My Bookkeeping App</Text>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionHeader}>Income</Text>
        {/* List of income transactions */}
        <TransactionList transactions={incomeTransactions} />
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionHeader}>Expenses</Text>
        {/* List of expense transactions */}
        <TransactionList transactions={expenseTransactions} />
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionHeader}>Summary</Text>
        {/* Display a summary of income and expenses */}
        <Summary income={incomeTransactions} expenses={expenseTransactions} />
      </View>

      <TouchableOpacity
        style={styles.addButton}
        onPress={() => {
          // Navigate to a screen to add a new transaction
        }}
      >
        <Text style={styles.addButtonText}>Add Transaction</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

const TransactionList = ({ transactions }) => {
  return (
    <View>
      {transactions.map((transaction, index) => (
        <View key={index} style={styles.transactionItem}>
          <Text>{transaction.description}</Text>
          <Text>${transaction.amount}</Text>
        </View>
      ))}
    </View>
  );
};

const Summary = ({ income, expenses }) => {
  const totalIncome = income.reduce((sum, transaction) => sum + transaction.amount, 0);
  const totalExpenses = expenses.reduce((sum, transaction) => sum + transaction.amount, 0);
  const balance = totalIncome - totalExpenses;

  return (
    <View>
      <Text>Total Income: ${totalIncome}</Text>
      <Text>Total Expenses: ${totalExpenses}</Text>
      <Text>Balance: ${balance}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  header: {
    alignItems: 'center',
    marginBottom: 20,
  },
  headerText: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  section: {
    marginBottom: 20,
  },
  sectionHeader: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  transactionItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  addButton: {
    backgroundColor: '#007AFF',
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
  },
  addButtonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

// Sample data
const incomeTransactions = [
  { description: 'Salary', amount: 3000 },
  { description: 'Freelance Work', amount: 1000 },
];

const expenseTransactions = [
  { description: 'Rent', amount: 1000 },
  { description: 'Groceries', amount: 200 },
];

export default HomeScreen;
