import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, FlatList, TouchableOpacity, Picker } from 'react-native';

const GenreScreen = () => {
  const [genres, setGenres] = useState([]);
  const [selectedGenre, setSelectedGenre] = useState('All');
  const [filteredTransactions, setFilteredTransactions] = useState([]);

  useEffect(() => {
    // Fetch genres and transactions from an API or local storage
    // Replace this with your data source
    const fetchData = async () => {
      // Example: Fetch genres from an API
      const genresResponse = await fetch('your_genre_api_endpoint_here');
      const genresData = await genresResponse.json();
      setGenres(genresData);

      // Example: Fetch transactions from an API
      const transactionsResponse = await fetch('your_transactions_api_endpoint_here');
      const transactionsData = await transactionsResponse.json();
      setFilteredTransactions(transactionsData);
    };

    fetchData();
  }, []);

  useEffect(() => {
    // Filter transactions based on the selected genre
    if (selectedGenre === 'All') {
      setFilteredTransactions(transactions);
    } else {
      const filtered = transactions.filter((transaction) => transaction.genre === selectedGenre);
      setFilteredTransactions(filtered);
    }
  }, [selectedGenre]);

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerText}>Genre Page</Text>
      </View>

      <View style={styles.filterContainer}>
        <Text style={styles.filterLabel}>Select Genre:</Text>
        <Picker
          selectedValue={selectedGenre}
          onValueChange={(itemValue, itemIndex) => setSelectedGenre(itemValue)}
        >
          <Picker.Item label="All" value="All" />
          {genres.map((genre, index) => (
            <Picker.Item key={index} label={genre.name} value={genre.name} />
          ))}
        </Picker>
      </View>

      <FlatList
        data={filteredTransactions}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item }) => (
          <TransactionItem transaction={item} />
        )}
      />

      <TouchableOpacity
        style={styles.addButton}
        onPress={() => {
          // Navigate to the add transaction screen
        }}
      >
        <Text style={styles.addButtonText}>Add Transaction</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

const TransactionItem = ({ transaction }) => {
  return (
    <View style={styles.transactionItem}>
      <Text>{transaction.description}</Text>
      <Text>${transaction.amount}</Text>
      <Text>Genre: {transaction.genre}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  header: {
    alignItems: 'center',
    marginBottom: 20,
  },
  headerText: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  filterContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  filterLabel: {
    marginRight: 10,
  },
  transactionItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  addButton: {
    backgroundColor: '#007AFF',
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
  },
  addButtonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default GenreScreen;
