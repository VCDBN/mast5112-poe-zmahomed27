import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, FlatList, TouchableOpacity } from 'react-native';

const HistoryScreen = () => {
  const [transactions, setTransactions] = useState([]);

  useEffect(() => {
    // Fetch transaction history from an API or local storage
    // Replace this with your data source
    const fetchData = async () => {
      // Example: Fetch transactions from an API
      const response = await fetch('your_api_endpoint_here');
      const data = await response.json();
      setTransactions(data);
    };

    fetchData();
  }, []);

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerText}>Transaction History</Text>
      </View>

      <FlatList
        data={transactions}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item }) => (
          <TransactionItem transaction={item} />
        )}
      />

      <TouchableOpacity
        style={styles.addButton}
        onPress={() => {
          // Navigate to the add transaction screen
        }}
      >
        <Text style={styles.addButtonText}>Add Transaction</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

const TransactionItem = ({ transaction }) => {
  return (
    <View style={styles.transactionItem}>
      <Text>{transaction.description}</Text>
      <Text>${transaction.amount}</Text>
      <Text>{transaction.date}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  header: {
    alignItems: 'center',
    marginBottom: 20,
  },
  headerText: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  transactionItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  addButton: {
    backgroundColor: '#007AFF',
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
  },
  addButtonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default HistoryScreen;
