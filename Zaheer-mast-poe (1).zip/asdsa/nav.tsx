import * as React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Image } from 'react-native';
import screen1 from './screen1';
import screen2 from './screen2';
import screen3 from './screen3';


const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

function MainNavigator() {
  return (
<Tab.Navigator>
    <Tab.Screen
    name="HOME"
    component={screen1}
    options={{
   tabBarIcon: ({ focused, color, size }) => (
   <Image
       source={require('./home.png')}
     style={{ width: size, height: size, tintColor: color }}
            />
          ),
        }}
      />
      <Tab.Screen
        name="SCREEN1"
        component={screen2}
        options={{
       tabBarIcon: ({ focused, color, size }) => (
         <Image
        source={require('./user.png')}
        style={{ width: size, height: size, tintColor: color }}
            />
          ),
        }}
      />
      <Tab.Screen
        name="SCREEN2"
        component={screen3}
       options={{
       tabBarIcon: ({ focused, color, size }) => (
            <Image
        source={require('./shopping-cart.png')}
       style={{ width: size, height: size, tintColor: color }}
            />
          ),
        }}
      />
    </Tab.Navigator>
  );
}

export default function App() {
  return (
   <NavigationContainer>
 <Stack.Navigator>
    <Stack.Screen
    name="Main"    component={MainNavigator}
     options={{ headerShown: false }}
     />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

